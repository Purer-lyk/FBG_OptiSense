# 三会话dBm训练

测试准确率：93.54%
验证准确率：96.25%
模型：C:\lyk\laser\FBG_OptiSense_Studio_多机通用版_开发源码_v1.0.4\Python\outputs\model_comparisons\sensor_token26_dbm_three_sessions_random_v1\sensor_token_dbm_selected.pt

随机帧划分，非跨会话性能。原始数据未修改。具体指标及参数见Word和JSON。
